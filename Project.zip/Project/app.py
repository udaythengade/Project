from flask import Flask, render_template, request, redirect, session
from db_config import get_db_connection

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def home():
    return redirect('/login')

# Signup
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, email, password, role) VALUES (%s, %s, %s, %s)",
                       (username, email, password, role))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/login')
    return render_template('signup.html')

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['username'] = user['username']

            if user['role'] == 'teacher':
                return redirect('/dashboard_teacher')
            elif user['role'] == 'volunteer':
                return redirect('/dashboard_volunteer')
            elif user['role'] == 'student':
                return redirect('/dashboard_student')
        return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

# Teacher Dashboard
@app.route('/dashboard_teacher')
def dashboard_teacher():
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect('/login')

    teacher_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM events WHERE created_by = %s", (teacher_id,))
    events = cursor.fetchall()

    cursor.execute("SELECT SUM(budget) AS total_budget FROM events WHERE created_by = %s", (teacher_id,))
    total_budget = cursor.fetchone()['total_budget'] or 0

    cursor.execute("""
        SELECT SUM(e.cost) AS total_expenses
        FROM expenses e
        JOIN events ev ON e.event_id = ev.id
        WHERE ev.created_by = %s
    """, (teacher_id,))
    total_expenses = cursor.fetchone()['total_expenses'] or 0

    remaining_budget = total_budget - total_expenses

    cursor.close()
    conn.close()

    return render_template('dashboard_teacher.html',
                           teacher_name=session['username'],
                           events=events,
                           total_budget=total_budget,
                           remaining_budget=remaining_budget,
                           total_events=len(events))

# Create Event
@app.route('/create_event', methods=['GET', 'POST'])
def create_event():
    if 'user_id' not in session or session['role'] != 'teacher':
        return redirect('/login')

    if request.method == 'POST':
        title = request.form['title']
        date = request.form['date']
        budget = request.form['budget']
        description = request.form['description']
        created_by = session['user_id']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO events (title, date, budget, description, created_by)
            VALUES (%s, %s, %s, %s, %s)
        """, (title, date, budget, description, created_by))
        conn.commit()
        cursor.close()
        conn.close()

        return redirect('/dashboard_teacher')

    return render_template('create_event.html')
@app.route('/register_event_form/<int:event_id>', methods=['GET', 'POST'])
def register_event_form(event_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect('/login')

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    # Get event details
    cursor.execute("SELECT * FROM events WHERE id = %s", (event_id,))
    event = cursor.fetchone()

    if request.method == 'POST':
        interest = request.form['interest']
        comment = request.form['comment']

        # Check if already registered
        cursor.execute("SELECT * FROM registrations WHERE user_id=%s AND event_id=%s", (user_id, event_id))
        existing = cursor.fetchone()

        if not existing:
            cursor.execute("""
                INSERT INTO registrations (user_id, event_id, status)
                VALUES (%s, %s, 'registered')
            """, (user_id, event_id))
            conn.commit()

        cursor.close()
        conn.close()
        return redirect('/dashboard_student')

    cursor.close()
    conn.close()
    return render_template('register_event_form.html', event=event)

# Volunteer Dashboard
@app.route('/dashboard_volunteer')
def dashboard_volunteer():
    if 'user_id' not in session or session['role'] != 'volunteer':
        return redirect('/login')

    volunteer_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM events")  # You can filter assigned events later
    events = cursor.fetchall()

    for event in events:
        cursor.execute("SELECT SUM(cost) AS total_expense FROM expenses WHERE event_id = %s", (event['id'],))
        expense = cursor.fetchone()['total_expense'] or 0
        event['remaining_budget'] = event['budget'] - expense

    cursor.execute("SELECT SUM(cost) AS total_expenses FROM expenses WHERE added_by = %s", (volunteer_id,))
    total_expenses = cursor.fetchone()['total_expenses'] or 0

    cursor.close()
    conn.close()

    return render_template('dashboard_volunteer.html',
                           volunteer_name=session['username'],
                           assigned_events=events,
                           assigned_events_count=len(events),
                           total_expenses=total_expenses)

# Add Expense
@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    if 'user_id' not in session or session['role'] != 'volunteer':
        return redirect('/login')

    volunteer_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        event_id = request.form['event_id']
        item_name = request.form['item_name']
        cost = request.form['cost']
        note = request.form['note']

        cursor.execute("""
            INSERT INTO expenses (event_id, added_by, item_name, cost)
            VALUES (%s, %s, %s, %s)
        """, (event_id, volunteer_id, item_name, cost))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/dashboard_volunteer')

    cursor.execute("SELECT * FROM events")
    events = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('add_expense.html', assigned_events=events)

# Student Dashboard
@app.route('/dashboard_student')
def dashboard_student():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect('/login')

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM events WHERE date >= CURDATE()")
    events = cursor.fetchall()

    cursor.execute("SELECT event_id FROM registrations WHERE user_id = %s", (user_id,))
    registered_ids = [row['event_id'] for row in cursor.fetchall()]

    for event in events:
        event['registered'] = event['id'] in registered_ids

    cursor.close()
    conn.close()

    return render_template('dashboard_student.html',
                           student_name=session['username'],
                           upcoming_events=events,
                           registered_count=len(registered_ids),
                           completed_count=0)
@app.route('/view_event/<int:event_id>')
def view_event(event_id):
    if 'user_id' not in session or session['role'] not in ['teacher', 'volunteer', 'student']:
        return redirect('/login')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Get event details
    cursor.execute("SELECT * FROM events WHERE id = %s", (event_id,))
    event = cursor.fetchone()

    # Get expenses for this event
    cursor.execute("SELECT item_name, cost, timestamp, added_by FROM expenses WHERE event_id = %s", (event_id,))
    expenses = cursor.fetchall()

    # Calculate total expenses
    cursor.execute("SELECT SUM(cost) AS total_expense FROM expenses WHERE event_id = %s", (event_id,))
    total_expense = cursor.fetchone()['total_expense'] or 0

    remaining_budget = event['budget'] - total_expense

    cursor.close()
    conn.close()
    

    return render_template('view_event.html',
                           event=event,
                           expenses=expenses,
                           total_expense=total_expense,
                           remaining_budget=remaining_budget)


@app.route('/view_event_student/<int:event_id>')
def view_event_student(event_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect('/login')

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Get event details
    cursor.execute("SELECT * FROM events WHERE id = %s", (event_id,))
    event = cursor.fetchone()

    # Check registration status
    cursor.execute("SELECT status FROM registrations WHERE user_id = %s AND event_id = %s", (user_id, event_id))
    reg = cursor.fetchone()
    status = reg['status'] if reg else "Not Registered"
    cursor.close()
    conn.close()

    return render_template('view_event_student.html',
                           event=event,
                           status=status)

# Register for Event
@app.route('/register_event_form/<int:event_id>', methods=['GET', 'POST'])
def register_event_form_by_id(event_id):
    # your logic here
    if 'user_id' not in session or session['role'] != 'student':
        return redirect('/login')

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Get event details
    cursor.execute("SELECT * FROM events WHERE id = %s", (event_id,))
    event = cursor.fetchone()

    if request.method == 'POST':
        prn = request.form['prn']
        name = request.form['name']
        program = request.form['program']
        interest = request.form['interest']
        comment = request.form['comment']

        # Check if already registered
        cursor.execute("SELECT * FROM registrations WHERE user_id=%s AND event_id=%s", (user_id, event_id))
        existing = cursor.fetchone()

        if not existing:
            cursor.execute("""
                INSERT INTO registrations (user_id, event_id, prn, name, program, interest, comment)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (user_id, event_id, prn, name, program, interest, comment))
            conn.commit()

        cursor.close()
        conn.close()
        return redirect('/dashboard_student')

    cursor.close()
    conn.close()
    return render_template('register_event_form.html', event=event)

# View Registered Events
@app.route('/registered_events')
def registered_events():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect('/login')

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT e.title, e.date, r.status, e.id
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        WHERE r.user_id = %s
    """, (user_id,))
    events = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('registered_event.html', registered_events=events)
if __name__ == '__main__':
    app.run(debug=True)